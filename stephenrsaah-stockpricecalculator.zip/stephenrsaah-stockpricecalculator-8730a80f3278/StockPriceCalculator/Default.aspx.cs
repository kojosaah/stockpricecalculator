﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.VisualBasic.FileIO;
using Microsoft.Office.Interop.Excel;
using Page = System.Web.UI.Page;
using DataTable = System.Data.DataTable;

namespace StockPriceCalculator
{
    
    public partial class Default : Page
    {


        protected DataTable GetAppleDataFromCSV()
        {
            DataTable csvData = new DataTable();
            if (FileUpload1.HasFile)
            {
                string FileSaveWithPath = Server.MapPath("~/FilesUpload/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(FileSaveWithPath);

               
                try
                {
                    using (TextFieldParser csvReader = new TextFieldParser(FileSaveWithPath))
                    {
                        csvReader.SetDelimiters(new string[] { "," });
                        csvReader.HasFieldsEnclosedInQuotes = true;
                        string[] colFields = csvReader.ReadFields();
                        foreach (string column in colFields)
                        {
                            DataColumn datecolumn = new DataColumn(column);
                            datecolumn.AllowDBNull = true;
                            csvData.Columns.Add(datecolumn);
                        }
                        while (!csvReader.EndOfData)
                        {
                            string[] fieldData = csvReader.ReadFields();
                            //Making empty value as null
                            for (int i = 0; i < fieldData.Length; i++)
                            {
                                if (fieldData[i] == "")
                                {
                                    fieldData[i] = null;
                                }
                            }
                            csvData.Rows.Add(fieldData);
                        }
                    }

                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;
                }
              
            }
            else
            {
                lblError.Text = "Unable to recognize file.";
            }
            return csvData;
        }

        protected void UploadAppleData(object sender, EventArgs e)
        {
            //DataTable dt = new DataTable();
            //dt = GetAppleDataFromCSV();
            //GridView1.DataSource = dt;
            //GridView1.DataBind();
            try
            {
                DataTable applecsvData = new DataTable();
                //if (applecsvData.Rows.Count > 0)
                //{
                    applecsvData = GetAppleDataFromCSV();
                    string connectionString =
                        "Data Source=(local);Initial Catalog=StocksCSV;"
                        + "Integrated Security=true";

                    using (SqlBulkCopy bulkCopyTable1 = new SqlBulkCopy(connectionString))
                    {
                        bulkCopyTable1.DestinationTableName = "AppleInc";

                        foreach (var column in applecsvData.Columns)
                            bulkCopyTable1.ColumnMappings.Add(column.ToString(), column.ToString());

                        bulkCopyTable1.WriteToServer(applecsvData);
                    }
                    Label1.Text = string.Format("({0}) records has been loaded to the table AppleInc.", applecsvData.Rows.Count);
                //}
                //else
                //{
                //    Label2.Text = "File is empty or File exists in database.";
                    //using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=StocksCSV;"
                    //    + "Integrated Security=true"))
                    //{

                    //connection.Open();
                    //SqlCommand comm = new SqlCommand("SELECT COUNT(*) FROM AppleInc", connection);
                    //Int32 count = Convert.ToInt32(comm.ExecuteScalar());
                    //if (count > 1)
                    //{
                    //    Label2.Text = "File exist in database";
                    //}
                    //else
                    //{
                    //    Label2.Text = "File is empty or File exists in database.";
                    //}

                    // }

               // }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
            }
        }

        protected DataTable GetSPDataFromCSV()
        {
            DataTable csvData = new DataTable();
            if (FileUpload2.HasFile)
            {
                string FileSaveWithPath = Server.MapPath("~/FilesUpload/") + Path.GetFileName(FileUpload2.PostedFile.FileName);
                FileUpload2.SaveAs(FileSaveWithPath);


                try
                {
                    using (TextFieldParser csvReader = new TextFieldParser(FileSaveWithPath))
                    {
                        csvReader.SetDelimiters(new string[] { "," });
                        csvReader.HasFieldsEnclosedInQuotes = true;
                        string[] colFields = csvReader.ReadFields();
                        foreach (string column in colFields)
                        {
                            DataColumn datecolumn = new DataColumn(column);
                            datecolumn.AllowDBNull = true;
                            csvData.Columns.Add(datecolumn);
                        }
                        while (!csvReader.EndOfData)
                        {
                            string[] fieldData = csvReader.ReadFields();
                            //Making empty value as null
                            for (int i = 0; i < fieldData.Length; i++)
                            {
                                if (fieldData[i] == "")
                                {
                                    fieldData[i] = null;
                                }
                            }
                            csvData.Rows.Add(fieldData);
                        }
                    }

                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;
                }

            }
            else
            {
                lblError.Text = "Unable to recognize file.";
            }
            return csvData;
        }

        protected void UploadSPData(object sender, EventArgs e)
        {
            try
            {
                DataTable spCsvData = new DataTable();
                
                //if (spCsvData.Rows.Count > 0)
                //{
                    spCsvData = GetSPDataFromCSV();
                    string connectionString =
                        "Data Source=(local);Initial Catalog=StocksCSV;"
                        + "Integrated Security=true";

                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connectionString))
                    {
                        bulkCopy.DestinationTableName = "SP500";

                        foreach (var column in spCsvData.Columns)
                            bulkCopy.ColumnMappings.Add(column.ToString(), column.ToString());

                        bulkCopy.WriteToServer(spCsvData);
                    }
                    Label1.Text = string.Format("({0}) records has been loaded to the table S&P500.", spCsvData.Rows.Count);
                //}
                //else
                //{
                //    Label2.Text = "File is empty or File exists in database.";
                    //using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=StocksCSV;"
                    //    + "Integrated Security=true"))
                    //{
                    //    connection.Open();
                    //    SqlCommand comm = new SqlCommand("SELECT COUNT(*) FROM SP500", connection);
                    //    Int32 count = Convert.ToInt32(comm.ExecuteScalar());
                    //    if (count >1)
                    //    {
                    //        Label2.Text = "File exist in database";
                    //    }
                    //    else
                    //    {
                    //        Label2.Text = "File is empty.";
                    //    }

                    //}

               // }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
            }
        }
        

        protected void CalculateStats(object sender, EventArgs e)
        {
            CopyAdjCloseAppleToList();
            CopyAdjCloseSP500ToList();
            List<decimal> appleReturns = CalculateReturns(CopyAdjCloseAppleToList());
            List<decimal> sp500Returns = CalculateReturns(CopyAdjCloseSP500ToList());

            var ary1 = appleReturns.Select(item => Convert.ToDouble(item)).ToArray();
            var ary2 = sp500Returns.Select(item => Convert.ToDouble(item)).ToArray();

            var application = new Application();

            var worksheetFunction = application.WorksheetFunction;

            div1.InnerHtml = "Correlation coefficient r is " + worksheetFunction.Correl(ary1, ary2);


            div2.InnerHtml = "The Standard Deviation for Apple returns is " + worksheetFunction.StDev(ary1);

            div3.InnerHtml = "The Standard Deviation for S&P500 returns is " + worksheetFunction.StDev(ary2);

     
        }

        private List<decimal> CopyAdjCloseAppleToList()
        {
            List<decimal> adjCLoseApple = new List<decimal>();
            SqlConnection conn = new SqlConnection("server=(local);database=StocksCSV;Integrated Security=true");
            SqlCommand cmd = new SqlCommand("select AdjClose from AppleInc", conn);
            SqlDataReader dr;
            try
            {
                conn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    adjCLoseApple.Add(dr.GetDecimal(dr.GetOrdinal("AdjClose")));

                }
                dr.Close();
            }
            catch (Exception exp)
            {
                lblError.Text = exp.Message;              
            }
            finally
            {

                conn.Close();
            }
            return adjCLoseApple;
        }

        private List<decimal> CopyAdjCloseSP500ToList()
        {
            List<decimal> adjCLoseApple = new List<decimal>();
            SqlConnection conn = new SqlConnection("server=(local);database=StocksCSV;Integrated Security=true");
            SqlCommand cmd = new SqlCommand("select AdjClose from SP500", conn);
            SqlDataReader dr;
            try
            {
                conn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    adjCLoseApple.Add(dr.GetDecimal(dr.GetOrdinal("AdjClose")));
                }
                dr.Close();
            }
            catch (Exception exp)
            {

                lblError.Text = exp.Message;
            }
            finally
            {
                conn.Close();
            }

            return adjCLoseApple;
            //Console.WriteLine(adjCLoseApple.Count);

            //foreach (var numbers in adjCLoseApple)
            //{
            //    Console.WriteLine(numbers);
            //}
        }

        private List<decimal> CalculateReturns(List<decimal> adjClose)
        {
            List<decimal> returnsOnStock = new List<decimal>();
            for (int i = 0; i <= adjClose.Count - 2; i++)
            {
                int j = i + 1;
                decimal finalReturns = (adjClose.ElementAt(j) / adjClose.ElementAt(i)) - 1;
                returnsOnStock.Add(finalReturns);
            }

            //foreach (var numbers in returnsOnStock)
            //   {
            //     Console.WriteLine(numbers);
            //   }
            //Console.WriteLine(returnsOnStock.Count);
            return returnsOnStock;
        }
    }

}
